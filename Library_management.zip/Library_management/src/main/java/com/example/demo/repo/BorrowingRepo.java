package com.example.demo.repo;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.entity.Book;
import com.example.demo.entity.Borrowing;
import com.example.demo.entity.User;


public interface BorrowingRepo extends JpaRepository<Borrowing,Integer>{
	List<Borrowing> findByReturnedFalseAndReturnDateBefore(LocalDate currentDate);
	List<Borrowing> findByBookAndUser(Book book, User user);
	List<Borrowing> findByUserUserid(int userId);
	List<Borrowing> findByBookId(Long bookId);
	List<Borrowing> findByBookReservedTrue();
	
//	static List<Borrowing> findByReturnedFalseAndReturnDateBefore(LocalDate currentDate) {
//		// TODO Auto-generated method stub
//		return null;
//	}

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

	

}
