package com.example.demo.mapper;

import com.example.demo.dto.BookDto;
import com.example.demo.entity.Book;

public class BookMapper {
	public static Book bookdtoBook(BookDto bdto) 
	{
		Book b=new Book();
		b.setId(bdto.getId());
		b.setAuthor(bdto.getAuthor());
		b.setGenre(bdto.getGenre());
		b.setIsdn(bdto.getIsdn());
		b.setName(bdto.getName());
		return b;
	}
	
	public static BookDto BookToBookDto(Book book)
	{
		BookDto b=new BookDto();
		b.setAuthor(book.getAuthor());
		b.setGenre(book.getGenre());
		b.setId(book.getId());
		b.setIsdn(book.getIsdn());
		b.setName(book.getName());
		return b;
	}

}
