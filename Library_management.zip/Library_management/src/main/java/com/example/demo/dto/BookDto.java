package com.example.demo.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public class BookDto {
	private Long id;
	 @NotNull(message = "Isdn cannot be blank")
	private Long isdn;
	 @NotBlank(message = "book name cannot be blank")
	private String name;
	 @NotBlank(message = "author cannot be blank")
	private String author;
	 @NotBlank(message = "book genre cannot be blank")
	private String genre;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getIsdn() {
		return isdn;
	}
	public void setIsdn(Long isdn) {
		this.isdn = isdn;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public String getGenre() {
		return genre;
	}
	public void setGenre(String genre) {
		this.genre = genre;
	}
	@Override
	public String toString() {
		return "BookDto [id=" + id + ", isdn=" + isdn + ", name=" + name + ", author=" + author + ", genre=" + genre
				+ "]";
	}
	public BookDto(Long id, @NotNull(message = "Isdn cannot be blank") Long isdn,
			@NotBlank(message = "book name cannot be blank") String name,
			@NotBlank(message = "author cannot be blank") String author,
			@NotBlank(message = "book genre cannot be blank") String genre) {
		super();
		this.id = id;
		this.isdn = isdn;
		this.name = name;
		this.author = author;
		this.genre = genre;
	}
	public BookDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	 
	 

}
