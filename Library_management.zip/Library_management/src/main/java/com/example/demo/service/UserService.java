package com.example.demo.service;

import com.example.demo.dto.RegisterDto;
import com.example.demo.entity.User;
import com.example.demo.repo.RoleRepository;
import com.example.demo.repo.UserRepository;

public interface UserService {
	
	public void saveUser(RegisterDto regdto);
	
	 User findByEmail(String email);
	 
	public String  viewBorrwedBooks(int userId);

	
	
	

}
