package com.example.demo.entity;

import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;

@Entity
public class Book {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long id;
	@Column(name = "isdn", nullable = true)
	private Long isdn;
	
	private String name;
	private String author;
	private String genre;
	
	
	
	private boolean isBookAvial=true;
	
	private boolean reserved;
	@OneToMany(mappedBy="book",fetch = FetchType.EAGER)
	private List<Borrowing> borrowings;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getIsdn() {
		return isdn;
	}
	public void setIsdn(Long isdn) {
		this.isdn = isdn;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public String getGenre() {
		return genre;
	}
	public void setGenre(String genre) {
		this.genre = genre;
	}
	
	
	
	public boolean isReserved() {
		return reserved;
	}
	public void setReserved(boolean reserved) {
		this.reserved = reserved;
	}
	public List<Borrowing> getBorrowings() {
		return borrowings;
	}
	public void setBorrowings(List<Borrowing> borrowings) {
		this.borrowings = borrowings;
		
	}
	
	
	public boolean isBookAvial() {
		return isBookAvial;
	}
	public void setBookAvial(boolean isBookAvial) {
		this.isBookAvial = isBookAvial;
	}
	public Book(Long id, Long isdn, String name, String author, String genre,List<Borrowing> borrowings,boolean isBookAvial,boolean reserved) {
		super();
		this.id = id;
		this.isdn = isdn;
		this.name = name;
		this.author = author;
		this.genre = genre;
		this.borrowings=borrowings;
		this.isBookAvial=isBookAvial;
		this.reserved=reserved;
	}
	public Book() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Book [id=" + id + ", isdn=" + isdn + ", name=" + name + ", author=" + author + ", genre=" + genre + ",reserved="+reserved+"]";
	}
	
	

}
