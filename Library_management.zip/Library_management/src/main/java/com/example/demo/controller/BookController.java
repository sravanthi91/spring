package com.example.demo.controller;

import java.security.Principal;
import java.util.List;

import org.apache.catalina.User;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.demo.dto.BookDto;
import com.example.demo.entity.Book;
import com.example.demo.repo.BookRepository;
import com.example.demo.repo.UserRepository;
import com.example.demo.service.BookService;
import com.example.demo.service.BorrowingService;

import jakarta.validation.Valid;

@Controller

public class BookController {
private BookService bookservice;
private BookRepository bookrepo;
private UserRepository userrepo;
private BorrowingService borrowingservice;
	
	
	public BookController(BookService bookservice,BookRepository bookrepo,BorrowingService borrowingservice) {
		super();
		this.bookservice = bookservice;
		this.bookrepo=bookrepo;
		this.userrepo=userrepo;
		this.borrowingservice=borrowingservice;
	}



	@GetMapping("getbooks")
	public String getBooks(Model model) {
		List<BookDto> books=bookservice.getAllbooks();
		
		model.addAttribute("books", books);
		
		return "admin/books";
	}
	
	@GetMapping("/addBook")
	public String addBooks(Model model)
	{
		Book b=new Book();
		model.addAttribute("books", b);
		return "admin/addbook";
	}
	
	@PostMapping("/addbooks")
	public String saveBooks(@Valid @ModelAttribute("books") BookDto b,BindingResult result)
	{
		if(result.hasErrors())
		{
			return "admin/addbook";
		}
		
		bookservice.addBook(b);
		
		return "redirect:/getbooks";
		
	}
	@GetMapping("/admin/books/{id}/view")
	public String getBookById(@PathVariable("id") long id,Model model)
	{
		BookDto book=bookservice.getBookById(id);
		model.addAttribute("books", book);
		return "admin/View";
		
	}
	
	
	@GetMapping("/admin/books/{id}/edit")
	public String getBooksById(@PathVariable("id") long id,Model model)
	{
		BookDto book=bookservice.getBookById(id);
		model.addAttribute("books", book);
		return "admin/getBook";
		
	}
	
	@PostMapping("/admin/books/{id}/edited")
	public String editBooks(@ModelAttribute("books") BookDto dto,@PathVariable("id")long id)
	{
		
		dto.setId(id);
		//dto.setBook_id(id);
		bookservice.editBook(dto);
		return "redirect:/getbooks";
		
	}
	
	@GetMapping("/admin/books/{id}/delete")
	public String deleteBooks(@PathVariable ("id")long id)
	{
		bookservice.deleteBook(id);
		return "redirect:/getbooks";
		
	}
	
	@GetMapping("/page/{pageNo}")
	public String findPaginated(@PathVariable(value="pageNo") int pageNo,@RequestParam(name="sortField" ,defaultValue = "name" ) String sortField,@RequestParam(name="sortDir",defaultValue = "desc") String sortDir,Model model)
	{
		int pageSize=3;
		//Page<Book> page=bookservice.findPaginated(pageNo, pageSize);
		Page<Book> page=bookservice.findPaginated(pageNo, pageSize,sortField,sortDir);
		List<Book> list=page.getContent();
		
		model.addAttribute("currentPage", pageNo);
		System.out.println(pageNo);
		model.addAttribute("totalPage", page.getTotalPages());
		System.out.println(page.getTotalPages());
		model.addAttribute("totalEle", page.getNumberOfElements());
		System.out.println(page.getNumberOfElements());
		model.addAttribute("books", list);
		
		
		model.addAttribute("sortDir", sortDir);
		model.addAttribute("sortField", sortField);
		model.addAttribute("sortReverse",sortDir.equals("asc")?"desc":"asc");
		return "admin/booksp";
		
	}
	
	@PutMapping("/{bookId}/reserve")
    public ResponseEntity<?> reserveBook(@PathVariable Long bookId,@PathVariable int userId) {
        try {
            bookservice.reserveBook(bookId,userId);
            return ResponseEntity.ok("Book reserved successfully.");
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }
	
	


}
