package com.example.demo.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Library {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long id;
    private String librarianName;
    private boolean librarian;
	public Library(Long id, String librarianName, boolean librarian) {
		super();
		this.id = id;
		this.librarianName = librarianName;
		this.librarian = librarian;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getLibrarianName() {
		return librarianName;
	}
	public void setLibrarianName(String librarianName) {
		this.librarianName = librarianName;
	}
	public boolean isLibrarian() {
		return librarian;
	}
	public void setLibrarian(boolean librarian) {
		this.librarian = librarian;
	}
	@Override
	public String toString() {
		return "Library [id=" + id + ", librarianName=" + librarianName + ", librarian=" + librarian + "]";
	}
	public Library() {
		super();
		// TODO Auto-generated constructor stub
	}
    
    

}
