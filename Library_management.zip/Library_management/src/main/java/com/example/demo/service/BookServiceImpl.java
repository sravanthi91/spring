package com.example.demo.service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.example.demo.dto.BookDto;
import com.example.demo.entity.Book;
import com.example.demo.mapper.BookMapper;
import com.example.demo.repo.BookRepository;

@Service
public class BookServiceImpl implements BookService{
	
	private BookRepository bookrepo;
	

 



	public BookServiceImpl(BookRepository bookrepo) {
		super();
		this.bookrepo = bookrepo;
	}



	@Override
	public List<BookDto> getAllbooks() {
		// TODO Auto-generated method stub
		List<Book> books=bookrepo.findAll();
		return books.stream().map(BookMapper::BookToBookDto).collect(Collectors.toList());
	}



	@Override
	public void addBook(BookDto b) {
		// TODO Auto-generated method stub
		Book book=BookMapper.bookdtoBook(b);
		bookrepo.save(book);
		
	}



	@Override
	public BookDto getBookById(long id) {
		// TODO Auto-generated method stub
		Book b=bookrepo.findById(id).get();
		
		return BookMapper.BookToBookDto(b);
	}



	@Override
	public BookDto editBook(BookDto b) {
		// TODO Auto-generated method stub
		Book book=BookMapper.bookdtoBook(b);
		bookrepo.save(book);
		
		return BookMapper.BookToBookDto(book);
	}



	@Override
	public void deleteBook(long id) {
		// TODO Auto-generated method stub
		bookrepo.deleteById(id);
		
	
	}
//	@Override
//	public Page<Book> findPaginated(int pageNo, int pageSize) {
//		// TODO Auto-generated method stub
//		//Sort sort=sortOrder.equalsIgnoreCase(Sort.Direction.ASC.name())?Sort.by(sortField).ascending() :Sort.by(sortField).descending();
//		Pageable pageable=PageRequest.of(pageNo-1, pageSize);
//		return bookrepo.findAll(pageable);
//		
//	}





//	@Override
//	public Page<Book> findPaginated(int pageNo, int pageSize, String sortField, String sortDirection) {
//		// TODO Auto-generated method stub
//		Sort sort=sortDirection.equalsIgnoreCase(Sort.Direction.ASC.name())?Sort.by(sortField).ascending() :Sort.by(sortField).descending();
//		Pageable pageable=PageRequest.of(pageNo-1, pageSize,sort);
//		//Page<Book> b=bookrepo.findAll(pageable);
//		
//		
//		return this.bookrepo.findAll(pageable);
//		
//	}
	@Override
	public Page<Book> findPaginated(int pageNo, int pageSize, String sortField, String sortDir) {
	    Sort.Direction direction = Sort.Direction.ASC;
	    
	    if (sortDir.equalsIgnoreCase("desc")) {
	        direction = Sort.Direction.DESC;
	    }

	    Sort sort = Sort.by(direction, sortField);
	    Pageable pageable = PageRequest.of(pageNo - 1, pageSize, sort);

	    return bookrepo.findAll(pageable);
	}



	@Override
	public void reserveBook(Long bookId,int userId) {
		// TODO Auto-generated method stub
		Optional<Book> book=bookrepo.findById(bookId);
		if(book.isPresent())
		{
			Book b=book.get();
			if(!b.isBookAvial() && b.isReserved())
			{
				b.setReserved(true);
                bookrepo.save(b);
			}
			else {
                throw new RuntimeException("Book is not available for reservation.");
            }
        } else {
            throw new RuntimeException("Book not found.");
        }
		}



	
		
	}

	
	


	

	
	
	



	
	
	


