package com.example.demo.entity;

public class reserve {
	private String bookTitle;
    private int userId;
    private String username;
    
    
    
    
    
	public reserve(String bookTitle, int userId, String username) {
		super();
		this.bookTitle = bookTitle;
		this.userId = userId;
		this.username = username;
	}





	public reserve() {
		super();
		// TODO Auto-generated constructor stub
	}





	public String getBookTitle() {
		return bookTitle;
	}





	public void setBookTitle(String bookTitle) {
		this.bookTitle = bookTitle;
	}





	public int getUserId() {
		return userId;
	}





	public void setUserId(int userId) {
		this.userId = userId;
	}





	public String getUsername() {
		return username;
	}





	public void setUsername(String username) {
		this.username = username;
	}





	@Override
	public String toString() {
		return "reserve [bookTitle=" + bookTitle + ", userId=" + userId + ", username=" + username + "]";
	}
    
    

}
