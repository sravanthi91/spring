package com.example.demo.entity;

import java.time.LocalDate;
import java.time.LocalDateTime;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Entity
public class Borrowing {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int borrwingId;
	
	private Long bookId;
	
	@ManyToOne
	@JoinColumn(name="userid")
	private User user;
	
	@ManyToOne
	@JoinColumn(name="id")
	private Book book;
	
	
	
	private LocalDate borrowDate;
	private LocalDate returnDate;
	
	private boolean returned;
	
	public int getBorrwingId() {
		return borrwingId;
	}
	public void setBorrwingId(int borrwingId) {
		this.borrwingId = borrwingId;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public Book getBook() {
		return book;
	}
	public void setBook(Book book) {
		this.book = book;
	}
	public LocalDate getBorrowDate() {
		return borrowDate;
	}
	
	public void setBorrowDate(LocalDate borrowDate) {
		this.borrowDate = borrowDate;
	}
	public LocalDate getReturnDate() {
		return returnDate;
	}
	public void setReturnDate(LocalDate returnDate) {
		this.returnDate = returnDate;
	}
	
	
	
	
	public boolean isReturned() {
		return returned;
	}
	public void setReturned(boolean returned) {
		this.returned = returned;
	}
	public Long getBookId() {
		return bookId;
	}
	public void setBookId(Long bookId) {
		this.bookId = bookId;
	}
	@Override
	public String toString() {
		return "Borrowing [borrwingId=" + borrwingId + ", user=" + user + ", book=" + book + ", BorrowDate="
				+ borrowDate + ", ReturnDate=" + returnDate + ",bookId="+ bookId + " + returned="+ returned+"]";
	}
	public Borrowing(int borrwingId, User user, Book book, LocalDate borrowDate, LocalDate returnDate ,Long bookId,boolean returned) {
		super();
		this.borrwingId = borrwingId;
		this.user = user;
		this.book = book;
		this.borrowDate = borrowDate;
		this.returnDate = returnDate;
		this.bookId=bookId;
		this.returned=returned;
	}
	public Borrowing() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	

}
