package com.example.demo.service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.List;


import org.springframework.stereotype.Service;

import com.example.demo.entity.Book;
import com.example.demo.entity.Borrowing;
import com.example.demo.entity.Library;
import com.example.demo.entity.User;
import com.example.demo.entity.reserve;
import com.example.demo.repo.BookRepository;
import com.example.demo.repo.BorrowingRepo;
import com.example.demo.repo.LibrarianRepo;
import com.example.demo.repo.UserRepository;

@Service                                     
public class BorrowingServiceImpl implements BorrowingService {
	
	
	private LibrarianRepo libraryrepo;
	private UserRepository userrepo;
	private BookRepository bookrepo;
	private BorrowingRepo borrowrepo;
	

	public BorrowingServiceImpl(LibrarianRepo libraryrepo, UserRepository userrepo, BookRepository bookrepo,BorrowingRepo borrowrepo) {
		super();
		this.libraryrepo = libraryrepo;
		this.userrepo = userrepo;
		this.bookrepo = bookrepo;
		this.borrowrepo=borrowrepo;
	}



	@Override
	public boolean issueBook(Long librarianId, int userId, Long bookId) {
		// TODO Auto-generated method stub
		Library librarian=libraryrepo.findById(librarianId).get();
		User user =userrepo.findById(userId).get();
		Book book =bookrepo.findById(bookId).get();
		
		if(librarian.isLibrarian())
		{
			System.out.println("library");
			if(user!=null &&  book!=null  && book.isBookAvial())
			{
				
				book.setBookAvial(false);
				
				System.out.println("HII");
				Borrowing borrowing = new Borrowing();
				borrowing.setUser(user);
		        //borrowing.setUser(user);
		        borrowing.setBook(book);
		        borrowing.setBookId(book.getId());
		        borrowing.setBorrowDate(LocalDate.now());
		        borrowing.setReturnDate(LocalDate.now().plusDays(10));
		        //borrowing.setReturnDate(LocalDate.now().plusDays(10));
		        borrowrepo.save(borrowing);
		        return true;
			}
		}
		return false;
		
		
		
	}



	@Override
	public boolean returnBook(int borrowingId) {
		// TODO Auto-generated method stub
		Optional<Borrowing> b=borrowrepo.findById(borrowingId);
		if(b.isPresent())
		{
			
			
			Borrowing borrowing=b.get();
			if(borrowing.isReturned())
			{
				return false;
			}
		     
			// Book has already been returned
			
			
		       
			borrowing.setReturnDate(LocalDate.now());
			borrowing.getBook().setBookAvial(true);
			borrowing.setReturned(true);
			
			borrowrepo.save(borrowing);
			System.out.println(borrowing.getBook().isBookAvial());
			
			return true;
		}
		
		else
		{
		
		return false;
		}
	}



	@Override
	public boolean isOverdue(Borrowing borrowing) {
		if(!borrowing.isReturned() && LocalDate.now().isAfter(borrowing.getReturnDate()));
		// TODO Auto-generated method stub
		return true;
	}



	@Override
	public void sendOverdueReminder() {
		// TODO Auto-generated method stub
		
		java.util.List<Borrowing> overdueBorrowings = borrowrepo.findByReturnedFalseAndReturnDateBefore(LocalDate.now());
		for(Borrowing borrow:overdueBorrowings)
		{
			if(isOverdue(borrow))
			{
				System.out.print(borrow.getBorrwingId());
			}
		}
	}
	
	public List<reserve> getReservedBooksAndUsersDetails() {
        // Retrieve all borrowings where the book is reserved
        List<Borrowing> reservedBorrowings = borrowrepo.findByBookReservedTrue();
        for(Borrowing b:reservedBorrowings)
        {
        	System.out.println(b.toString());
        }

        // Map Borrowing objects to ReservedBookDetails
        return reservedBorrowings.stream()
                .map(this::mapToreserve)
                .collect(Collectors.toList());
    }

    private reserve mapToreserve(Borrowing borrowing) {
        reserve details = new reserve();
        details.setBookTitle(borrowing.getBook().getName());
        details.setUserId(borrowing.getUser().getUserid());
        details.setUsername(borrowing.getUser().getUsername());
        
        return details;
    }



	@Override
	public void notifyUser(Book book) {
		// TODO Auto-generated method stub
		 System.out.println("Book '" + book.getName() + "' is now available. You can reserve it.");
    }



	



	@Override
	public boolean reserveBook(Long bookId, int userId) {
		// TODO Auto-generated method stub
		Book book=bookrepo.findById(bookId).get();
		User user=userrepo.findById(userId).get();
        
        if(book.isBookAvial() )
        {
        	System.out.println("book is avialable no need to resaerve it");
        	return false;
        }
        else if(!book.isReserved())
        //else
        {
        	book.setReserved(true);
        	bookrepo.save(book);
        
        	Borrowing reservation = new Borrowing();
            reservation.setBook(book);
            reservation.setUser(user);
           // borrowrepo.save(reservation);
        	System.out.println("book is  resaervd");
        	return true;
        }
        return false;
        	
        	
        	
        	
        	
        	
        	
	
		
	}



	@Override
	public List<Borrowing> getUserReservations(int userId) {
		// TODO Auto-generated method stub
		 return borrowrepo.findByUserUserid(userId);
	}



	@Override
	public List<Borrowing> getBookReservations(Long bookId) {
		// TODO Auto-generated method stub
		return borrowrepo.findByBookId(bookId);
	}
	
	public void checkAndNotifyReservedBooks() {
        List<Book> reservedBooks = bookrepo.findByReserved(true);
        for (Book book : reservedBooks) {
            if (book.isBookAvial()) {
                List<Borrowing> borrowings = book.getBorrowings();
                for (Borrowing borrowing : borrowings) {
                    if (!borrowing.isReturned()) {
                        User user = borrowing.getUser();
                        sendNotification(user, book);
                    }
                }
            }
        }

	
	


	
	




		
	}



	@Override
	public void sendNotification(User user, Book book) {
		// TODO Auto-generated method stub
		System.out.println("Notification sent to user " + user.getUsername() + " for book " + book.getName());
		
		
	}
}
		
	




	



	
		
	        
		
	


