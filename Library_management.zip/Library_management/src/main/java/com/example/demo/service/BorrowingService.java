package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.Book;
import com.example.demo.entity.Borrowing;
import com.example.demo.entity.User;
import com.example.demo.entity.reserve;

public interface BorrowingService {
	
	public boolean issueBook(Long librarianId, int userId, Long bookId);
	
	public boolean returnBook(int borrowingId);
	
	public boolean isOverdue(Borrowing borrowing);
	 public void sendOverdueReminder();
	 public boolean reserveBook(Long bookId, int userId);
	 public List<Borrowing> getUserReservations(int userId);
	 public List<Borrowing> getBookReservations(Long bookId);
	 void notifyUser(Book book);
	 

	public List<reserve> getReservedBooksAndUsersDetails();

	public void checkAndNotifyReservedBooks();
	public void sendNotification(User user, Book book);
	

}
