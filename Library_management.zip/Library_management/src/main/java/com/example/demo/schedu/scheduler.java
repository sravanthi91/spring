package com.example.demo.schedu;

import java.util.List;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.example.demo.entity.Book;
import com.example.demo.entity.Borrowing;
import com.example.demo.entity.User;
import com.example.demo.repo.BookRepository;

@Component
public class scheduler {
	
	private BookRepository bookrepo;
	
	
	public scheduler(BookRepository bookrepo) {
		super();
		this.bookrepo = bookrepo;
	}

	@Scheduled(cron = "0 */1 * * * *")
    public void checkAndNotifyReservedBooks() {
        // Method implementation
        List<Book> reservedBooks = bookrepo.findByReserved(true);
        for (Book book : reservedBooks) {
            if (book.isBookAvial()) {
                List<Borrowing> borrowings = book.getBorrowings();
                for (Borrowing borrowing : borrowings) {
                    if (borrowing.isReturned()) {
                        User user = borrowing.getUser();
                        sendNotification(user, book);
                    }
                }
            }
        }
    }

    private void sendNotification(User user, Book book) {
        // Notification logic
        // Implement your notification sending mechanism here
        System.out.println("Notification sent to user: " + user.getUsername() + " for book: " + book.getName());
    }

}
