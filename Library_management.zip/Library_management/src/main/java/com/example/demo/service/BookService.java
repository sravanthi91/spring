package com.example.demo.service;

import java.util.List;

import org.springframework.data.domain.Page;

import com.example.demo.dto.BookDto;
import com.example.demo.entity.Book;

public interface BookService {
public List<BookDto> getAllbooks();
	
	public void addBook(BookDto b);
	
	public BookDto getBookById(long id);
	public BookDto editBook(BookDto b);
	
	public void deleteBook(long id);
	public Page<Book> findPaginated(int pageNo,int pageSize,String sortField,String sortDirection);
	public void reserveBook(Long bookId, int userId);


	
	

}
