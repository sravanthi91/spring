package com.example.demo.Util;

public enum ROLE {
	ROLE_ADMIN,
	ROLE_LIBRARIAN,
	ROLE_USER

}
