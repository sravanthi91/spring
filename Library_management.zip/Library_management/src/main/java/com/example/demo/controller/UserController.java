package com.example.demo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

import com.example.demo.service.UserService;

@Controller
public class UserController {
	
	private UserService userservice;
	
	
	
	public UserController(UserService userservice) {
		super();
		this.userservice = userservice;
	}



	@GetMapping("/Borrowbooks")
	public String getBorrowingBooks()
	{
		userservice.viewBorrwedBooks(2);
		
		return "librarian/failurepage";
	}

}
