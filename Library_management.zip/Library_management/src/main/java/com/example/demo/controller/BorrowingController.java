package com.example.demo.controller;

import java.security.Principal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;


import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.demo.dto.BookDto;
import com.example.demo.entity.Book;
import com.example.demo.entity.Borrowing;
import com.example.demo.entity.User;
import com.example.demo.entity.reserve;
import com.example.demo.mapper.BookMapper;
import com.example.demo.repo.BookRepository;
import com.example.demo.repo.BorrowingRepo;
import com.example.demo.repo.UserRepository;
import com.example.demo.service.BookService;
import com.example.demo.service.BorrowingService;
import com.example.demo.service.UserService;

@Controller
public class BorrowingController {
	
	private BorrowingService borrowservice;
	private UserService userservice;
	private BookService bookservice;
	private BorrowingRepo borrowingrepo;
	private BookRepository bookrepo;
	private UserRepository userrepo;

	public BorrowingController(BorrowingService borrowservice,BorrowingRepo borrowingrepo,BookService bookservice,UserService userservice) {
		super();
		this.borrowservice = borrowservice;
		this.borrowingrepo=borrowingrepo;
		this.bookservice=bookservice;
		this.userservice=userservice;
		
	}
	
	@GetMapping("/issueBook")
	public String issueBooks()
	{
		return "librarian/issuebooks";
	}
	@GetMapping("/reserveBook")
	public String reserveBooks()
	{
		return "librarian/reserveBooks";
	}
	
	
	@PostMapping("/issueBook")
    public String issueBook(
            @RequestParam("lid") Long librarianId,
            @RequestParam("userid") int userId,
            @RequestParam("bookid") Long bookId) {

		 boolean issuanceSuccess=borrowservice.issueBook(librarianId, userId, bookId);

        // Redirect to a success page or another appropriate page
		 if(issuanceSuccess)
		 {
        return "redirect:/issueBook?success";
		 }
		 return "redirect:/issueBook?error"; 
		 
    }
	
	@PostMapping("/reserveBook")
	public String reserveBookPost(@RequestParam("bookid") Long bookId,@RequestParam("userid")int userId)
	{
		Boolean b=borrowservice.reserveBook(bookId, userId);
		if(b)
		{
			return "redirect:/reserveBook?success";
		}
		
		return "redirect:/reserveBook?error";
		
		
	}
	@GetMapping("/returnBook")
	public String returnBooks()
	{
		return "librarian/returnbooks";
	}
	
	@PostMapping("/returnBook")
    public String returnBook(
            @RequestParam("lid") int borrowingId)
             {

		 boolean issuanceSuccess=borrowservice.returnBook(borrowingId);

        // Redirect to a success page or another appropriate page
		 if(issuanceSuccess)
		 {
        return "redirect:/returnBook?success";
		 }
		 return "redirect:/returnBook?error";
		 
    }
	
	
	@GetMapping("/overdue-reminders")
    public  ResponseEntity<String>sendOverdueReminders() {
		borrowservice.sendOverdueReminder();
		return ResponseEntity.ok("Overdue reminders sent successfully.");
		
	
    }
	
	@PostMapping("/reserve")
    public String reserveBook(@RequestParam("bookId") Long bookId, @RequestParam("userId") int userId) {
        bookservice.reserveBook(bookId, userId);
        return "redirect:/";
    }
	
	@GetMapping("/reserved-books")
    public ResponseEntity<List<reserve>> getReservedBooksAndUsers() {
        List<reserve> reservedBooksDetails = borrowservice.getReservedBooksAndUsersDetails();
        return new ResponseEntity<>(reservedBooksDetails, HttpStatus.OK);
    }
	
	
	@GetMapping("/user")
	public String userDet()
	{
		return "user/header";
	}
	




    
    
   

	 
	
	
	
	
	
	

}
