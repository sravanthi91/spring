package com.example.demo.service;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Service;

import com.example.demo.dto.RegisterDto;
import com.example.demo.entity.Borrowing;
import com.example.demo.entity.Role;
import com.example.demo.entity.User;
import com.example.demo.repo.RoleRepository;
import com.example.demo.repo.UserRepository;

@Service
public class UserServiceImpl implements UserService{
	private RoleRepository rolerepo;
	private UserRepository userrepo;
	
	
	public UserServiceImpl(RoleRepository rolerepo, UserRepository userrepo) {
		super();
		this.rolerepo = rolerepo;
		this.userrepo = userrepo;
	}


	@Override
	public void saveUser(RegisterDto regdto) {
		// TODO Auto-generated method stub
		User u=new User();
		u.setUsername(regdto.getFirst_name() +"" +regdto.getLast_name());
		u.setEmail(regdto.getEmail());
		u.setPassword(regdto.getPassword());
		Role role=rolerepo.findByRole("ROLE_LIBRARIAN");
		u.setRoles(Arrays.asList(role));
		userrepo.save(u);
		
		
		
		
	}


	@Override
	public User findByEmail(String email) {
		return userrepo.findByEmail(email);
		
		
	}


	@Override
	public String viewBorrwedBooks(int userId) {
		// TODO Auto-generated method stub
		User u=userrepo.findById(userId).get();
		List<Borrowing> borrowings=u.getBorrowings();
		
		StringBuilder result = new StringBuilder();
        for (Borrowing borrowing : borrowings) {
            if (!borrowing.isReturned()) { // Only consider not returned books
                String bookName = borrowing.getBook().getName();
                LocalDate dueDate = borrowing.getReturnDate();

                // Append book name and due date to the result string
                result.append("Book: ").append(bookName).append(", Due Date: ").append(dueDate).append("\n");
            }
        }
		System.out.print(result);
		
		
		
		return result.toString();
	}

}
